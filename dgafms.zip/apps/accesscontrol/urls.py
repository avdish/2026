# Core Django imports
from django.urls import path

# Apps views import
from apps.accesscontrol.views import ( 
    LogInView,
    LogOutView,
    # PasswordChangeView,
    LandingView,
    IndexView,
    StaffManagementView,
    )

app_name = 'accesscontrol'

# apps urls
urlpatterns = [
    # path('change-password/', PasswordChangeView.as_view(), name="change_password"),
    path('logout/', LogOutView.as_view(), name="logout"),
    path('auth/login/', LogInView.as_view(), name='login'),
    path('auth/index/', IndexView.as_view(), name='index'),
    path('auth/staff-management/', StaffManagementView.as_view(), name='staff_management'),
    path('', LandingView.as_view(), name='landing'),
]