# Standard Library Imports
import string
import secrets

# Django Core Imports
from django.shortcuts import render, redirect           
from django.contrib import messages                     
from django.contrib.auth import authenticate, login, logout     
from django.contrib.auth import update_session_auth_hash 
from django.contrib.auth.models import User             
from django.contrib.auth.views import PasswordChangeView  
from django.db.models import Q                          
from django.urls import reverse_lazy                    
from django.views.generic import TemplateView, View     
from django.contrib.auth.mixins import LoginRequiredMixin  
from django.contrib.messages.views import SuccessMessageMixin  
from django.views.decorators.cache import never_cache   
from django.utils.decorators import method_decorator    

# Local Application Imports
from apps.accesscontrol.models import CustomUser, Role   # Custom user model and role model


# landing page view
class LandingView(TemplateView):
    template_name = "landing.html"


# Login page view
@method_decorator(never_cache, name='dispatch')
class LogInView(View):
    template_name = "accesscontrol/login.html"

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('accesscontrol:index')  # Already logged in
        return render(request, self.template_name)

    def post(self, request):
        if request.user.is_authenticated:
            return redirect('accesscontrol:index')  # Already logged in

        # Get form data directly
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()
        remember_me = request.POST.get("remember_me")  # Checkbox value

        # Check if username and password are provided
        if not username or not password:
            messages.error(request, "Both username and password are required.")
            return redirect('accesscontrol:login')

        # Authenticate user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # Set session expiry based on "Remember Me"
            if remember_me:
                request.session.set_expiry(1209600)  # 2 weeks
            else:
                request.session.set_expiry(0)  # Browser session
            
            roles = user.roles.values_list('name', flat=True)
            print('roles: ', roles)

            if "data_entry" in roles:
                return redirect('accesscontrol:data_entry_dashboard')
            elif "admin" in roles:
                return redirect('accesscontrol:admin_dashboard')
            elif "approver" in roles:
                return redirect('accesscontrol:approver_dashboard')
            elif "manager" in roles:
                return redirect('accesscontrol:manager_dashboard')
            else:
                # Default fallback
                return redirect('accesscontrol:index')
            return redirect('accesscontrol:index')       
        else:
            messages.error(request, "Invalid username or password.")
            return redirect('accesscontrol:login')


# index page view
class IndexView(LoginRequiredMixin, TemplateView):
    template_name = "index.html"


# Staff Management View
class StaffManagementView(LoginRequiredMixin, View):

    template_name = "accesscontrol/staff_management.html"

    def get(self, request):

        staff_list = CustomUser.objects.filter(is_deleted=False)
        roles = Role.objects.all()

        context = {
            "staff_list": staff_list,
            "roles": roles
        }

        return render(request, self.template_name, context)

    def post(self, request):

        first_name = request.POST.get("first_name")
        middle_name = request.POST.get("middle_name")
        last_name = request.POST.get("last_name")
        mobile_no = request.POST.get("mobile_no")
        email = request.POST.get("email")
        user_status = request.POST.get("user_status")

        roles_ids = request.POST.getlist("roles")  # ManyToMany
        temp_password_generated = ''.join(
            secrets.choice(string.ascii_letters + string.digits)
            for _ in range(10)
        )
        # Create User
        user = CustomUser.objects.create(
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            mobile_no=mobile_no,
            email=email,
            user_status=True if user_status == "True" else False,
            temp_password=temp_password_generated
        )

        
        user.set_password(temp_password_generated)  # Set the password using set_password method
        user.save()  # Save the user to apply the password change
        
        # Assign Roles
        if roles_ids:
            user.roles.set(roles_ids)

        messages.success(request, "Staff created successfully")

        return redirect("accesscontrol:staff_management")


# Log Out View
class LogOutView(LoginRequiredMixin,View):
    login_url = 'accesscontrol:login'

    def get(self, request):
        logout(request)
        messages.success(request, "User logged out")
        return redirect('accesscontrol:login')

