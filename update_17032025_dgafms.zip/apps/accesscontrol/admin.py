from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from apps.accesscontrol.models import CustomUser, Role

# -----------------------------
# Role Admin
# -----------------------------
@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ('name', 'id', 'created_at', 'updated_at')
    search_fields = ('name',)
    ordering = ('name',)


# -----------------------------
# CustomUser Admin
# -----------------------------
@admin.register(CustomUser)
class CustomUserAdmin(DjangoUserAdmin):
    model = CustomUser

    # Fields to display in list view
    list_display = (
        'username', 'email', 'first_name', 'last_name', 'mobile_no',
        'user_status', 'is_staff', 'is_superuser', 'created_at', 'updated_at'
    )

    # Fields to filter by
    list_filter = ('user_status', 'is_staff', 'is_superuser', 'roles')

    # Fields to search by
    search_fields = ('username', 'email', 'first_name', 'last_name', 'mobile_no')

    # Fields in the admin form
    fieldsets = (
        ('Login & Password', {'fields': ('username', 'password')}),
        ('Personal Info', {'fields': (
            'first_name', 'middle_name', 'last_name', 'email', 'mobile_no', 'profile_image'
        )}),
        ('Roles & Permissions', {'fields': ('roles', 'user_status', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important Dates', {'fields': ('last_login', 'date_joined', 'created_at', 'updated_at')}),
        ('Temporary Password', {'fields': ('temp_password', 'temp_password_expiry', 'temp_password_used', 'is_password_change')}),
    )

    # Fields editable in the add user form
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'mobile_no', 'first_name', 'last_name', 'password1', 'password2', 'roles', 'user_status'),
        }),
    )

    filter_horizontal = ('roles', 'groups', 'user_permissions')
    ordering = ('username',)
    readonly_fields = ('created_at', 'updated_at')
