 	

# Django core forms import
from django import forms
from django.contrib.auth.forms import (
    AuthenticationForm,
)

from apps.accesscontrol.models import CustomUser


# Log In Form
class LoginUserForm(AuthenticationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'password']
