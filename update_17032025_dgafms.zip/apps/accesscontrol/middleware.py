from django.shortcuts import redirect
from django.urls import reverse

class LoginRequiredMiddleware:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        allowed_urls = [
            reverse("accesscontrol:login"),
            reverse("accesscontrol:login"),
            reverse("accesscontrol:landing"),
        ]

        # allow static and media
        if request.path.startswith("/assets/") or request.path.startswith("/content/"):
            return self.get_response(request)

        if not request.user.is_authenticated and request.path not in allowed_urls:
            return redirect("accesscontrol:login")

        return self.get_response(request)