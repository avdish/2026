# from django.core.exceptions import PermissionDenied

# class AdminRequiredMixin:

#     def dispatch(self, request, *args, **kwargs):

#         if not request.user.has_role("admin"):
#             raise PermissionDenied

#         return super().dispatch(request, *args, **kwargs)
    
from django.core.exceptions import PermissionDenied

class RoleRequiredMixin:

    allowed_roles = []

    def dispatch(self, request, *args, **kwargs):

        if not request.user.is_authenticated:
            raise PermissionDenied

        if not request.user.roles.filter(name__in=self.allowed_roles).exists():
            raise PermissionDenied

        return super().dispatch(request, *args, **kwargs)