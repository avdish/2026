import uuid
import os
import random
import string
import socket
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db import transaction
from django.utils import timezone

# ==============================
# Base Model
# ==============================

class BaseModel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    ip_address = models.CharField(max_length=100, null=True, blank=True)
    host_name = models.CharField(max_length=100, null=True, blank=True)

    class Meta:
        abstract = True
    
    def save(self, *args, **kwargs):

        request = kwargs.pop('request', None)

        if request:
            ip = request.META.get('HTTP_X_FORWARDED_FOR')
            if ip:
                ip = ip.split(',')[0]
            else:
                ip = request.META.get('REMOTE_ADDR')

            self.ip_address = ip

            try:
                self.host_name = socket.gethostbyaddr(ip)[0]
            except:
                self.host_name = None

        super().save(*args, **kwargs)


# ==============================
# Random Folder Generator
# ==============================

def generate_random_folder_name(length=8):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


def generate_unique_folder_path(folder_depth=3):
    return os.path.join(*(generate_random_folder_name() for _ in range(folder_depth)))


def profile_upload_path(instance, filename):
    folder = generate_unique_folder_path()
    return os.path.join("profile", folder, filename)


# ==============================
# Role Model
# ==============================

# from apps.accesscontrol.models import Role

# roles = ["sys_admin", "admin", "approver", "manager", "data_entry","higher_executive"]

# for role in roles:
#     Role.objects.get_or_create(name=role)

# print("Roles created successfully")

class Role(BaseModel):
    """Stores: SysAdmin, Admin, Approver, Manager etc."""

    name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.name


# ==============================
# Custom User Model
# ==============================

class CustomUser(AbstractUser, BaseModel):

    middle_name = models.CharField(max_length=255, blank=True, null=True)

    email = models.EmailField(unique=True)

    mobile_no = models.CharField(max_length=20, unique=True)

    profile_image = models.ImageField(
        upload_to=profile_upload_path,
        null=True,
        blank=True
    )

    roles = models.ManyToManyField(Role, related_name="users")

    user_status = models.BooleanField(default=True)

    temp_password = models.CharField(max_length=32, null=True, blank=True)
    temp_password_expiry = models.DateTimeField(null=True, blank=True)
    temp_password_used = models.BooleanField(default=False)

    is_deleted = models.BooleanField(default=False)
    is_password_change = models.BooleanField(default=False)

    USERNAME_FIELD = "username"


    REQUIRED_FIELDS = ['email', 'mobile_no', 'first_name', 'last_name', 'middle_name']

    def __str__(self):
        return f"{self.username} ({self.email})"

    # ==============================
    # Check Role
    # ==============================

    def has_role(self, role_name):
        return self.roles.filter(name=role_name).exists()
    
    # -----------------------------
    # Generate Username
    # -----------------------------
    def generate_username(self):
        """
        Generates a unique, sequential username in the format:
        the format:
        DGAFMS + YYYYMM + 0001
        """
        now = timezone.now()
        prefix = f"DGAFMS{now.strftime('%Y%m')}"

        with transaction.atomic():
            last_user = (
                CustomUser.objects.select_for_update()
                .filter(username__startswith=prefix)
                .order_by("-username")
                .first()
            )

            if last_user and last_user.username[-4:].isdigit():
                last_seq = int(last_user.username[-4:])
                new_seq = last_seq + 1
            else:
                new_seq = 1

            return f"{prefix}{new_seq:04d}"


    # ==============================
    # Auto Delete Old File on Update
    # ==============================

    def save(self, *args, **kwargs):

        # Auto-generate username if empty
        if not self.username:
            self.username = self.generate_username()

        try:
            old = CustomUser.objects.get(pk=self.pk)
        except CustomUser.DoesNotExist:
            old = None

        super().save(*args, **kwargs)

        if old and old.profile_image and old.profile_image != self.profile_image:

            old_path = old.profile_image.path

            if os.path.isfile(old_path):
                os.remove(old_path)

                folder = os.path.dirname(old_path)

                while True:
                    try:
                        os.rmdir(folder)
                        folder = os.path.dirname(folder)
                    except OSError:
                        break

    # ==============================
    # Auto Delete File on Delete
    # ==============================

    def delete(self, *args, **kwargs):

        if self.profile_image:

            path = self.profile_image.path

            if os.path.isfile(path):
                os.remove(path)

                folder = os.path.dirname(path)

                while True:
                    try:
                        os.rmdir(folder)
                        folder = os.path.dirname(folder)
                    except OSError:
                        break

        super().delete(*args, **kwargs)

    @property
    def is_admin(self):
        return self.has_role("admin")

    @property
    def is_sys_admin(self):
        return self.has_role("sys_admin")

    @property
    def is_approver(self):
        return self.has_role("approver")
    
    @property
    def is_manager(self):
        return self.has_role("manager")
    
    @property
    def is_data_entry(self):
        return self.has_role("data_entry")
    
    @property
    def is_higher_executive(self):
        return self.has_role("higher_executive")
    
    @property
    def dashboard_url(self):
        roles = list(self.roles.values_list('name', flat=True))

        role_redirects = {
            "admin": "accesscontrol:admin_dashboard",
            "data_entry": "accesscontrol:data_entry_dashboard",
            "approver": "accesscontrol:approver_dashboard",
            "manager": "accesscontrol:manager_dashboard",
            "higher_executive":"accesscontrol:higher_executive_dashboard", 
        }

        for role, url in role_redirects.items():
            if role in roles:
                return url

        return None