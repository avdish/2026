# Core Django imports
from django.urls import path

# Apps views import
from apps.accesscontrol.views import ( 
    LogInView,
    LogOutView,
    # PasswordChangeView,
    LandingView,
    StaffManagementView,
    UpdateStaffView,
    DownloadProfileView,
    DeleteStaffView,
    AdminDashboardView,
    DataEntryDashboardView,
    ManagerDashboardView,
    ApproverDashboardView,
    HigherExecutiveDashboardView,
    SysAdminDashboardView
    )

app_name = 'accesscontrol'

# apps urls
urlpatterns = [
    # path('change-password/', PasswordChangeView.as_view(), name="change_password"),
    path('logout/', LogOutView.as_view(), name="logout"),
    path('auth/login/', LogInView.as_view(), name='login'),

    path("admin-dashboard/", AdminDashboardView.as_view(), name="admin_dashboard"),
    path("data-entry-dashboard/", DataEntryDashboardView.as_view(), name="data_entry_dashboard"),
    path("manager-dashboard/", ManagerDashboardView.as_view(), name="manager_dashboard"),
    path("approver-dashboard/", ApproverDashboardView.as_view(), name="approver_dashboard"),
    path("higher-executive-dashboard/", HigherExecutiveDashboardView.as_view(), name="higher_executive_dashboard"),
    path("sys-admin-dashboard/", SysAdminDashboardView.as_view(), name="sys_admin_dashboard"),

    path("staff-delete/", DeleteStaffView.as_view(), name="staff_delete"),
    path('staff-management/', StaffManagementView.as_view(), name='staff_management'),
    path('staff-update/', UpdateStaffView.as_view(), name='update_staff'),
    path("staff-download-profile/<uuid:user_id>/", DownloadProfileView.as_view(), name="staff_download_profile"),
    path('', LandingView.as_view(), name='landing'),
]