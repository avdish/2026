# Standard Library Imports
import string
import secrets
import os

# Django Core Imports
from django.shortcuts import render, redirect           
from django.contrib import messages                     
from django.contrib.auth import authenticate, login, logout     
from django.contrib.auth import update_session_auth_hash 
from django.contrib.auth.models import User             
from django.contrib.auth.views import PasswordChangeView  
from django.db.models import Q                          
from django.urls import reverse_lazy                    
from django.views.generic import TemplateView, View     
from django.contrib.auth.mixins import LoginRequiredMixin  
from django.contrib.messages.views import SuccessMessageMixin  
from django.views.decorators.cache import never_cache   
from django.utils.decorators import method_decorator    
from django.http import FileResponse
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.core.exceptions import PermissionDenied


# Local Application Imports
from apps.accesscontrol.models import CustomUser, Role   # Custom user model and role model
from apps.accesscontrol.mixins import RoleRequiredMixin

# landing page view
class LandingView(TemplateView):
    template_name = "landing.html"


# Login page view
@method_decorator(never_cache, name='dispatch')
class LogInView(View):
    template_name = "accesscontrol/login.html"

    def redirect_by_role(self, request, user):
        dashboard = user.dashboard_url

        if dashboard:
            return redirect(dashboard)

        # No valid role → Access Denied
        logout(request)
        messages.error(request, "Access denied. No valid role assigned.")
        return redirect('accesscontrol:login')


    def get(self, request):
        if request.user.is_authenticated:
            return self.redirect_by_role(request, request.user)

        return render(request, self.template_name)


    def post(self, request):
        if request.user.is_authenticated:
            return self.redirect_by_role(request, request.user)

        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()
        remember_me = request.POST.get("remember_me")

        if not username or not password:
            messages.error(request, "Both username and password are required.")
            return redirect('accesscontrol:login')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)

            if remember_me:
                request.session.set_expiry(1209600)  # 2 weeks
            else:
                request.session.set_expiry(0)

            return self.redirect_by_role(request, user)

        messages.error(request, "Invalid username or password.")
        return redirect('accesscontrol:login')


# index page view
@method_decorator(never_cache, name='dispatch')
class AdminDashboardView( View):

    def get(self, request):
        return render(request, "accesscontrol/admin_dashboard.html")


@method_decorator(never_cache, name='dispatch')
class DataEntryDashboardView( View):

    def get(self, request):
        return render(request, "accesscontrol/data_entry_dashboard.html")


@method_decorator(never_cache, name='dispatch')
class ApproverDashboardView( View):

    def get(self, request):
        return render(request, "accesscontrol/approver_dashboard.html")


@method_decorator(never_cache, name='dispatch')
class ManagerDashboardView( View):

    def get(self, request):
        return render(request, "accesscontrol/manager_dashboard.html")


@method_decorator(never_cache, name='dispatch')
class HigherExecutiveDashboardView( View):

    def get(self, request):
        return render(request, "accesscontrol/higher_executive_dashboard.html")
    

@method_decorator(never_cache, name='dispatch')
class SysAdminDashboardView( View):

    def get(self, request):
        return render(request, "accesscontrol/sys_admin_dashboard.html")

# Staff Management View
class StaffManagementView( RoleRequiredMixin, View):

    allowed_roles = ["admin"]
    template_name = "accesscontrol/staff_management.html"

    def get(self, request):

        staff_list = CustomUser.objects.filter(is_deleted=False)
        roles = Role.objects.all()

        context = {
            "staff_list": staff_list,
            "roles": roles
        }

        return render(request, self.template_name, context)

    def post(self, request):

        first_name = request.POST.get("first_name")
        middle_name = request.POST.get("middle_name")
        last_name = request.POST.get("last_name")
        mobile_no = request.POST.get("mobile_no")
        email = request.POST.get("email")
        user_status = request.POST.get("user_status")

        roles_ids = request.POST.getlist("roles")  # ManyToMany
        temp_password_generated = ''.join(
            secrets.choice(string.ascii_letters + string.digits)
            for _ in range(10)
        )
        # Create User
        user = CustomUser.objects.create(
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            mobile_no=mobile_no,
            email=email,
            user_status=True if user_status == "True" else False,
            temp_password=temp_password_generated
        )

        
        user.set_password(temp_password_generated)  # Set the password using set_password method
        user.save()  # Save the user to apply the password change
        
        # Assign Roles
        if roles_ids:
            user.roles.set(roles_ids)

        messages.success(request, "Staff created successfully")

        return redirect("accesscontrol:staff_management")



@method_decorator(never_cache, name='dispatch')
class UpdateStaffView( RoleRequiredMixin, View):

    allowed_roles = ["admin"]

    def post(self, request):

        user_id = request.POST.get("user_id")
        first_name = request.POST.get("first_name")
        middle_name = request.POST.get("middle_name")
        last_name = request.POST.get("last_name")
        mobile = request.POST.get("mobile_no")
        email = request.POST.get("email")
        status = request.POST.get("user_status")
        role_id = request.POST.get("roles")

        profile_image = request.FILES.get("profile_image")

        try:
            user = CustomUser.objects.get(id=user_id)

            user.first_name = first_name
            user.middle_name = middle_name
            user.last_name = last_name
            user.mobile_no = mobile
            user.email = email
            user.user_status = True if status == "True" else False

            if profile_image:
                user.profile_image = profile_image

            user.save()

            # Update Role
            if role_id:
                role = Role.objects.get(id=role_id)
                user.roles.set([role])

            messages.success(request, "Staff updated successfully")

        except Exception as e:
            messages.error(request, f"Error updating staff: {str(e)}")

        return redirect("accesscontrol:staff_management")
    


class DownloadProfileView( RoleRequiredMixin, View):

    allowed_roles = ["admin"]

    def get(self, request, user_id):

        user = get_object_or_404(CustomUser, id=user_id)

        if not user.profile_image:
            return JsonResponse({"error": "No image found"}, status=404)

        file_path = user.profile_image.path
        file_name = os.path.basename(file_path)

        response = FileResponse(open(file_path, "rb"))
        response["Content-Disposition"] = f'attachment; filename="{file_name}"'

        return response


@method_decorator(never_cache, name="dispatch")
class DeleteStaffView( RoleRequiredMixin, View):

    allowed_roles = ["admin"]

    def post(self, request):
        user_id = request.POST.get("user_id")
        try:
            user = CustomUser.objects.get(id=user_id)

            user.is_deleted = True
            user.save()

            return JsonResponse({
                "status": "success",
                "message": "Staff deleted successfully"
            })

        except CustomUser.DoesNotExist:

            return JsonResponse({
                "status": "error",
                "message": "User not found"
            })
        

# Log Out View
class LogOutView(View):

    def get(self, request):
        logout(request)
        messages.success(request, "User logged out")
        return redirect('accesscontrol:landing')

