
jQuery(document).ready(function() {
$("input[type='date']").keydown(function (event) { event.preventDefault(); });


document.addEventListener('DOMContentLoaded', initializeGlobalInputValidationDivyang);
//jQuery('body').bind('cut copy paste', function (e) {
//	   	        e.preventDefault();
//});
});
//=============== pdf file and size validation ========================
function pdfFileSizeValidation(val, myfile, id, size, lbltik_id, lbl_id) {
	document.getElementById(lbl_id).innerHTML = "";
	document.getElementById(lbltik_id).innerHTML = "";

//	size = "5mb"; // hardcoded for demo purposes

	var ext = myfile.split('.').pop();
	if (ext.toLowerCase() != "pdf") {
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>Only Pdf File extension allowed.";
	} else if (size == "2mb" && val.files[0].size > 2097152) {
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 2 MB!";
	} else if (size == "200kb" && val.files[0].size > 204800) {
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 200 Kb!";
	} else if (size == "50kb" && val.files[0].size > 51200) {
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 50 Kb!";
	} else if (size == "20kb" && val.files[0].size > 20480) {
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 20 Kb!";
	} else if (size == "2kb" && val.files[0].size > 2048) {
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 2 Kb!";
	} else if (size == "5mb" && val.files[0].size > 5242880) {
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 5 MB!";
	} else {
		document.getElementById(lbltik_id).innerHTML = "<i class='fa fa-exclamationstik'></i>File Upload";
		document.getElementById(lbl_id).innerHTML = ""; // clear error message
	}
}

//=============== image file and size validation ========================

function imgFileSizeValidation(val, myfile, id, size, lbltik_id, lbl_id) {
	//	;CheckFileValidation
//	size = "5mb"
	document.getElementById(lbl_id).innerHTML = "";
	document.getElementById(lbltik_id).innerHTML = "";
	//	document.getElementById(lbl_id).innerHTML="";
	var a=myfile.split('.');
	if(a.length > 2)
	{
		$("#"+id).val("");
		document.getElementById(lbl_id).innerHTML="<i class='fa fa-exclamation'></i>Invalid File";  //Only Allowed Single '?' Extension
		return false;
	}	
	
	var txtlen=val.files[0].name.split('.');
	if(txtlen[0].length > 30)
	{
		$("#"+id).val("");
		document.getElementById(lbl_id).innerHTML="<i class='fa fa-exclamation'></i>File Name length must be less than or equal to 30";
		return false;
	}
	
	
	
	var ext = myfile.split('.').pop();
	if (ext.toLowerCase() != "png" && ext.toLowerCase() != "jpg" && ext.toLowerCase() != "jpeg") {
		//alert('Please Only Allowed *.png/.jpeg/.jpg File Extension');
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>Only Allowed *.png/.jpeg/.jpg File Extension";
	return false;
	}
	else if (size == "200kb" && val.files[0].size > 204800) {
		//alert("File Size Upto 200 Kb!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 200 Kb!";
	return false;
	}
	else if (size == "50kb" && val.files[0].size > 51200) {
		//alert("File Size Upto 50 Kb!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 50 Kb!";
	return false;
	}
	else if (size == "20kb" && val.files[0].size > 20480) {
		//alert("File Size Upto 20 Kb!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 20 Kb!";
	return false;
	}
	else if (size == "2kb" && val.files[0].size > 2048) {
		//alert("File Size Upto 2 Kb!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 2 Kb!";
	return false;
	}
	else if (size == "2mb" && val.files[0].size > 2097152) {
		//        alert("File Size Upto 2 Mb!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 2 Mb!";
	return false;
	} else if (size == "5mb" && val.files[0].size > 5242880) {
		//        alert("File Size Upto 2 Mb!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 5 Mb!";
	return false;
	}else if (size == "50mb" && val.files[0].size > 52428800) {
		//alert("File Size Upto 50 MB!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 50 MB!";
	return false;
	}else {
		//		  alert("Image Upload");
		document.getElementById(lbltik_id).innerHTML = "<i class='fa fa-exclamationstik'></i>Image Upload";
		document.getElementById(lbl_id).innerHTML = ""; // clear error message
return true;
	}
}

//=============== video file and size validation ========================
function videoFileSizeValidation(val, myfile, id, size, lbltik_id, lbl_id) {
	//	;
	document.getElementById(lbl_id).innerHTML = "";
	document.getElementById(lbltik_id).innerHTML = "";
//	size = "10mb";
	var ext = myfile.split('.').pop();
	if (ext.toLowerCase() != "mp4") {
		//alert('Please Only Allowed *.mp4, *.avi, *.mov, *.wmv File Extension');
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>Only Allowed *.mp4 File Extension";
	} else if (size == "100mb" && val.files[0].size > 104857600) {
		//alert("File Size Upto 100 MB!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 100 MB!";
	} else if (size == "50mb" && val.files[0].size > 52428800) {
		//alert("File Size Upto 50 MB!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 50 MB!";
	} else if (size == "20mb" && val.files[0].size > 20971520) {
		//alert("sizeFile Size Upto 20 MB!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 20 MB!";
	} else if (size == "10mb" && val.files[0].size > 10485760) {
		//alert("File Size Upto 10 MB!");
		$("#" + id).val("");
		document.getElementById(lbl_id).innerHTML = "<i class='fa fa-exclamation'></i>File Size Upto 10 MB!";
	} else {
		document.getElementById(lbltik_id).innerHTML = "<i class='fa fa-exclamationstik'></i>File Upload";
		document.getElementById(lbl_id).innerHTML = ""; // clear error message

	}
}


function currentDate() {

	//getting current date in master
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth() + 1;
	var yyyy = today.getFullYear();
	//	var HHMM = today.getHours() + ":" + today.getMinutes()
	if (dd < 10) {
		dd = '0' + dd;
	}
	if (mm < 10) {
		mm = '0' + mm;
	}
	today = yyyy + '-' + mm + '-' + dd;
	//	console.log(today);
	//	console.log(HHMM);
	return today;

}

function currentTime() {

	var today = new Date();
	var HHMM = today.getHours() + ":" + today.getMinutes()
	return HHMM;

}
function currentDateTime() {

	const today = new Date();
	const dd = today.getDate().toString().padStart(2, '0');
	const mm = (today.getMonth() + 1).toString().padStart(2, '0');
	const yyyy = today.getFullYear();
	const time = today.toLocaleTimeString('en-IN', {
		hour: '2-digit',
		minute: '2-digit',
		hour12: true
	});

	const formattedDate = `${dd}/${mm}/${yyyy}`;
	//	console.log(formattedDate);
	$('#todayDate').html(`<i class="fa-regular fa-calendar-days"></i>Last Updated Date : ${formattedDate}`);
	return formattedDate;

}
function visitorsCounter() {
	var visitCount = localStorage.getItem("page_view");

	if (visitCount) {
		visitCount = Number(visitCount) + 1;
		localStorage.setItem("page_view", visitCount);
	} else {
		visitCount = 1;
		localStorage.setItem("page_view", 1);
	}
	document.getElementById("counterVisitor").innerHTML = visitCount;
}


//===========onlyaplhabetand numeric     

function onlyAlphabetsNumeric(e, t) {
	//	;
	try {
		if (window.event) {
			var charCode = window.event.keyCode;
		} else if (e) {
			var charCode = e.which;
		} else {
			return true;
		}


		if (t.value.length == 0 && charCode == 32) {

			return false;
		}

		if (((charCode > 64 && charCode < 91)
			|| (charCode > 96 && charCode < 123)
			|| (charCode > 47 && charCode < 58) || charCode == 32))
			return true;
		else {
//			alert(" This Special Character Not Allowed. ");
			e.preventDefault();
			return false;
		}


	} catch (err) {
		// alert(err.Description);
	}
}



// only alphabet string
function onlyAlphabetsString(e, t) {
	try {
		if (window.event) {
			var charCode = window.event.keyCode;
		}
		else if (e) {
			var charCode = e.which;
		}
		else { return true; }
		
		if (t.value.length == 0 && charCode == 32) {
			return false;
		}
		if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 32)
			return true;
		else
//			alert(" This Special Character Not Allowed. ");
		return false;
	}
	catch (err) {
		alert(err.Description);
	}
}

function onlyAlphabetsNumericSomespecialcharacters(e, t) {
	
	try {
			if (window.event) {
				var charCode = window.event.keyCode;
			}
			else if (e) {
				var charCode = e.which;
			}
			else { return true; }
			if (t.value.length == 0 && charCode == 32) {
					return false;
			}
			if (t.value.length == 0 && charCode == 32) {

						return false;
			}
			if (
			( (charCode >= 48 && charCode <= 57) || // 0-9
			   (charCode >= 65 && charCode <= 90) || // A-Z
			   (charCode >= 97 && charCode <= 122) || // a-z
			   charCode === 40 || // (
			   charCode === 41 || // )
			   charCode === 91 || // [
			   charCode === 93 || charCode === 32 || charCode === 92 || charCode === 46 || charCode === 45 || charCode === 44 || charCode === 95)
		   )
				return true;
			else
//				alert(" This Special Character Not Allowed. ");
			return false;
		}
		catch (err) {
			alert(err.Description);
		}
	
    
}
function onlyAlphabetsNumericSomespecialcharacterstesting(e, t) {
	
	try {
			if (window.event) {
				var charCode = window.event.keyCode;
			}
			else if (e) {
				var charCode = e.which;
			}
			else { return true; }
			if (t.value.length == 0 && charCode == 32) {
					return false;
			}
			if (t.value.length == 0 && charCode == 32) {

						return false;
			}
			if (
			( (charCode >= 48 && charCode <= 57) || // 0-9
			   (charCode >= 65 && charCode <= 90) || // A-Z
			   (charCode >= 97 && charCode <= 122) || // a-z
			   charCode === 40 || // (
			   charCode === 41 || // )
			   charCode === 91 || // [
			   charCode === 93 || charCode === 32 || charCode === 92 || charCode === 46 || charCode === 45 || charCode === 44 || charCode === 95
		   	|| charCode === 33 || charCode === 34 || charCode === 35 || charCode === 37 || charCode === 38 || charCode === 39 || charCode === 63
			|| charCode === 64 || charCode === 92 || charCode === 123 || charCode === 125 ) // ]
		   )
				return true;
			else
//				alert(" This Special Character Not Allowed. ");
			return false;
		}
		catch (err) {
			alert(err.Description);
		}
	
    
}

// ONLY NUMERIC
function isNumberKey(evt, t) {
	var charCode = (evt.which) ? evt.which : evt.keyCode;

	//if(t.value==0){
	//$("#"+t.id).val("");
	//}
	if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	} else {
		if (charCode == 46) {
			return false;
		}
	}
	return true;
}




function emailCheck(emailAddres, id) {
	var email = emailAddres;
	if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email)) {
		alert('Please enter a valid email');
		$("#" + id).focus();
		$("#" + id).val("");
		return false;
	}
}
function checkgmail(email1,id) {

//document.getElementById(id).innerHTML = "";
if (/@gmail.com\s*$/.test(email1) || /@yahoo.com\s*$/.test(email1)) {

} else {

alert("Please Enter Valid Email Address");
$("#" + id).focus();
$("#" + id).val("");

return false;
}
}
function pincodevalidation(obj){
	var maxLength = 6;
	var charLength = obj.value.length;

	if(charLength > maxLength){
		    alert("Please Enter Pincode Should Be Less Then 6.");
			$("input#"+obj.id).focus();
			$('#' + obj.id).val('');
			return false;
	}
		        
		        
		        var minlength = 6;
//		     	 var charLength = $("input#pincode").val().length;
		     	
		            if(charLength < minlength){
		            		alert("Please Enter Pincode Should Be Minimum Of 6 Digit.");
		     			$("input#"+obj.id).focus();
						$('#' + obj.id).val('');
		     			return false;
		            }  
}
function mobileNumber(obj) {
	var maxLength = 10;
		var charLength = obj.value.length;

			if(charLength > maxLength){
				    alert("Please Enter 10 Digit Of Mobile Number.");
					$("input#"+obj.id).focus();
					$('#' + obj.id).val('');
					return false;
			}
				        
				        
				        var minlength = 10;
		//		     	 var charLength = $("input#pincode").val().length;
				     	
				            if(charLength < minlength){
				            		alert("Please Enter 10 Digit Of Mobile Number.");
				     			$("input#"+obj.id).focus();
								$('#' + obj.id).val('');
				     			return false;
				            }

	_mobile = obj.value;

	var regExp = /^[6789]\d{9}$/;
	if (_mobile == '' || !regExp.test(_mobile)) {
		alert('Please Enter Number Start with 6,7,8 or 9 Digit');
		$('#' + obj.id).focus();
		$('#' + obj.id).val('');
		return false;
	}
	
	
}

function loginIdvalidation(event,obj) {


const charCode = event.charCode; 

        // Allow: alphabets (A-Z, a-z), numbers (0-9), and '@' (ASCII 64)
        if (
            (charCode >= 48 && charCode <= 57) ||  // 0-9
            (charCode >= 65 && charCode <= 90) ||  // A-Z
            (charCode >= 97 && charCode <= 122) || // a-z
            charCode === 64 || charCode === 46 || charCode === 95// '@','.','_'
        ) {
            // Valid character, allow it
            return true;
        } else {
            return false;
        }
    // Test the input against the regex
//    return regex.test(input);
}

function emailkeypress(event,obj) {


const charCode = event.charCode; 

        // Allow: alphabets (A-Z, a-z), numbers (0-9), and '@' (ASCII 64)
        if (
            (charCode >= 48 && charCode <= 57) ||  // 0-9
            (charCode >= 97 && charCode <= 122) || // a-z
            charCode === 64 || charCode === 46  || charCode === 95// '@','.','_'
        ) {
            // Valid character, allow it
            return true;
        } else {
            return false;
        }
    // Test the input against the regex
//    return regex.test(input);
}

// function validatePassword(obj) {
// 	// Define the criteria
// 	password = obj.value;

// 	const minLength = 8;
// 	const hasUpperCase = /[A-Z]/.test(password);
// 	const hasLowerCase = /[a-z]/.test(password);
// 	const hasNumber = /\d/.test(password);
// 	const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

// 	// Check the password against the criteria
// 	if (password.length < minLength) {
// 		alert('Password must be at least 8 characters long.');
// 		$('#' + obj.id).focus();
// 		$('#' + obj.id).val('');
// 		return false;
// 	}
// 	if (!hasUpperCase) {
// 		alert('Password must contain at least one uppercase letter.');
// 		$('#' + obj.id).focus();
// 		$('#' + obj.id).val('');
// 		return false;
// 	}
// 	if (!hasLowerCase) {
// 		alert('Password must contain at least one lowercase letter.');
// 		$('#' + obj.id).focus();
// 		$('#' + obj.id).val('');
// 		return false;
// 	}
// 	if (!hasNumber) {
// 		alert('Password must contain at least one number.');
// 		$('#' + obj.id).focus();
// 		$('#' + obj.id).val('');
// 		return false;
// 	}
// 	if (!hasSpecialChar) {
// 		alert('Password must contain at least one special character.');
// 		$('#' + obj.id).focus();
// 		$('#' + obj.id).val('');
// 		return false;
// 	}

// 	return true;
// }


$(document).ready(function() {
	$(".scrollDown").on("click", function() {
	    $(window).scrollTop(0);
	});
	
	$(document).on('click', '.close_success', function() {
			   	$(".success_div").addClass("d-none");
	});
					
	setTimeout(timer1, 10000);
	
	
	
});

function timer1() {
    $(".success_div").addClass("d-none");
}

$(window).scroll(function() {    
        var scroll = $(window).scrollTop();

        
        if (scroll >= 300) {
            //clearHeader, not clearheader - caps H
            $("body").addClass("scr");
        }
        if (scroll <= 300) {
            //clearHeader, not clearheader - caps H
            $("body").removeClass("scr");
        }
    });

	// function myFunction(obj) {
	//   var x = obj;
	//   if (x.type === "password") {
	//     x.type = "text";
	//   } else {
	//     x.type = "password";
	//   }
	}
	
	
	
	 function onlyAlphabetDivyang(inputText) {
      // Define the allowed character codes
      const allowedCharCodes = [
              ...Array.from({ length: 10 }, (_, i) => i + 48), // 0-9
              ...Array.from({ length: 26 }, (_, i) => i + 65), // A-Z
              ...Array.from({ length: 26 }, (_, i) => i + 97), // a-z
              40, // (
              41, // )
              91, // [
              93, // ]
              32, // space
              92, // \
              46, // .
              45, // -
              44, // ,
              95, // _
              33, // !
              34, // "
              35, // #
              37, // %
              38, // &
              39, // '
              63, // ?
              64, // @
              123, // {
              125   // }
      ];

      // Check each character in the input text
      for (let char of inputText) {
              const charCode = char.charCodeAt(0);
              if (!allowedCharCodes.includes(charCode)) {
                      return false; // Found a disallowed character
              }
      }
      
      return true; // All characters are allowed
}
	
function myFunction(obj) {
  var x = obj;
//   if (x.type === "password") {
//     x.type = "text";
//   } else {
//     x.type = "password";
  }
}
  //---------------------------------------------- new globle input validation -------------------------------------------------------------
          function initializeGlobalInputValidationDivyang() {
              let blockedAttempts = 0;
              let validChars = 0;
              
              const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="search"], textarea, select');
              
              inputs.forEach(input => {
                  const allowDot = input.hasAttribute('data-allow-dot');
                     const allowpass = input.hasAttribute('data-allow-pass');
                     
                       const allowcoma = input.hasAttribute('data-allow-coma');
                       
                        const allowlink = input.hasAttribute('data-allow-link');
						
						const allowbracatecp = input.hasAttribute('data-allow-bracatecp');
  //                !#$%^&*(),?":{}|<>
  //                const charPattern = allowDot ? /[a-zA-Z0-9@.!#$%^&*(),?":{}|<> ]/ : /[a-zA-Z0-9@ ]/;
  //                const cleanPattern = allowDot ? /[^a-zA-Z0-9@.!#$%^&*(),?":{}|<> ]/g : /[^a-zA-Z0-9@ ]/g;
                  
  				let charPattern = /[a-zA-Z0-9 ]/;
  				let cleanPattern = /[^a-zA-Z0-9 ]/g;

  				if (allowDot) {
  					charPattern = /[a-zA-Z0-9@. _-]/;
					cleanPattern = /[^a-zA-Z0-9@. _-]/g;

  				} else if (allowpass) {
//  					charPattern = /[a-zA-Z0-9@.!#$%^&*(),?":{}|<>-_ ]/;
//  					cleanPattern = /[^a-zA-Z0-9@.!#$%^&*(),?":{}|<>-_ ]/g;
					
					charPattern = /[a-zA-Z0-9@.!#$%^&*(),?":{}|<> _-]/;
					cleanPattern = /[^a-zA-Z0-9@.!#$%^&*(),?":{}|<> _-]/g;

  				}else if (allowcoma){
  					charPattern = /[a-zA-Z0-9@, ]/;
  					cleanPattern = /[^a-zA-Z0-9@, ]/g;
  					
  				} else  if (allowlink){
//  					charPattern = /[a-zA-Z0-9@:/. ]/;
//  					cleanPattern = /[^a-zA-Z0-9@:/. ]/g;
				charPattern = /[a-zA-Z0-9@:/. -]/;
			    cleanPattern = /[^a-zA-Z0-9@:/. -]/g;
  					
  				} else 	if (allowbracatecp){
						charPattern = /[a-zA-Z0-9:/.,() ]/;
						cleanPattern = /[^a-zA-Z0-9:/.,() ]/g;

					} else if (input.tagName.toLowerCase() === 'textarea') {
  						charPattern = /[a-zA-Z0-9@:/.,"() ]/;
  					cleanPattern = /[^a-zA-Z0-9@:/.,"() ]/g;
     				 }
                  
                  if (input.tagName.toLowerCase() !== 'select') {
                      // Prevent invalid characters on keydown
                      input.addEventListener('keydown', function(e) {
                          const char = e.key;
                          const isValidChar = charPattern.test(char);
                          const isControlKey = ['Backspace', 'Delete', 'Tab', 'Enter', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Escape', 'Control', 'Alt', 'Shift', 'Meta'].includes(char);
                          const isShortcut = e.ctrlKey || e.metaKey; // Allow Ctrl/Cmd shortcuts
                          
                          if (!isValidChar && !isControlKey && !isShortcut && char.length === 1) {
                              e.preventDefault();
  //                            addBlockedAnimation(input);
                              blockedAttempts++;
                          }
                      });
                      
                      input.addEventListener('input', function() {
                          const originalValue = this.value;
                          const cleanValue = originalValue.replace(cleanPattern, '');
                          
                          if (originalValue !== cleanValue) {
                              this.value = cleanValue;
                              const removedChars = originalValue.length - cleanValue.length;
                              blockedAttempts += removedChars;
  //                            addBlockedAnimation(this);
                          }
                          
                          const currentLength = cleanValue.length;
                          const previousLength = this.previousLength || 0;
                          if (currentLength > previousLength) {
                              validChars += (currentLength - previousLength);
                          }
                          this.previousLength = currentLength;
                      });
                      
                      input.addEventListener('paste', function(e) {
                          setTimeout(() => {
                              const originalValue = this.value;
                              const cleanValue = originalValue.replace(cleanPattern, '');
                              
                              if (originalValue !== cleanValue) {
                                  this.value = cleanValue;
                                  const removedChars = originalValue.length - cleanValue.length;
                                  blockedAttempts += removedChars;
  //                                addBlockedAnimation(this);
                              }
                          }, 0);
                      });
                  }
              });
          }

        //   // Initialize when DOM is loaded
        //   document.addEventListener('DOMContentLoaded', initializeGlobalInputValidationDivyang);

        //   document.querySelectorAll('form').forEach(form => {
        //       form.addEventListener('submit', function(e) {
        //           e.preventDefault();
        //           alert('Form submission prevented for demo. All inputs are validated!');
        //       });
        //   });
		  
		  
		  function mobileNumber(obj) {

		  	  _mobile = obj.value;

		  	  var regExp = /^[6789]\d{9}$/;
		  	  if (_mobile == '' || !regExp.test(_mobile)) {
		  	  alert('Please enter a valid 10-digit cell phone number starting with 6, 7, 8, or 9.');
		  	  $('#' + obj.id).focus();
		  	  $('#' + obj.id).val('');
		  	  return false;
		  	  }

		  	  }	
			  
			  
			  function validateNumberInput(e) {
			  	  		  const input = e.target;
			  	  		  const value = input.value;

			  	  		  // Allow control keys (backspace, delete, arrow keys)
			  	  		  if (
			  	  		    e.key === 'Backspace' ||
			  	  		    e.key === 'Delete' ||
			  	  		    e.key.startsWith('Arrow') ||
			  	  		    e.key === 'Tab'
			  	  		  ) {
			  	  		    return;
			  	  		  }

			  	  		  // Prevent non-digit characters
			  	  		  if (!/[0-9]/.test(e.key)) {
			  	  		    e.preventDefault();
			  	  		    return;
			  	  		  }

			  	  		  // Prevent input if length already 10
			  	  		  if (value.length >= 10) {
			  	  		    e.preventDefault();
			  	  		    return;
			  	  		  }
			  	  		  // If first digit, restrict to 6,7,8,9
			  	  		  if (value.length === 0) {
			  	  		    if (!['6', '7', '8', '9'].includes(e.key)) {
			  	  		      e.preventDefault();
			  	  		      alert('Number must start with 6, 7, 8, or 9');
			  	  		    }
			  	  		  }
			  	  		}
		  	  

