(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner(0);


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });


    // International Tour carousel
    $(".InternationalTour-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: false,
        dots: true,
        loop: true,
        margin: 25,
        nav : false,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsiveClass: true,
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:2
            },
            1200:{
                items:3
            }
        }
    });


    // packages carousel
    $(".packages-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: false,
        dots: false,
        loop: true,
        margin: 25,
        nav : true,
        navText : [
            '<i class="fa fa-arrow-left"></i>',
            '<i class="fa fa-arrow-right"></i>'
        ],
        responsiveClass: true,
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:2
            },
            1200:{
                items:3
            }
        }
    });


    // testimonial carousel
    

    
   // Back to top button
   $(window).scroll(function () {
    if ($(this).scrollTop() > 300) {
        $('.back-to-top').fadeIn('slow');
    } else {
        $('.back-to-top').fadeOut('slow');
    }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    }); 

})(jQuery);

$(document).ready(function () {
	
	var $affectedElements = $("p, h1, h2, h3, h4, h5, h6 , a , li ,ul ,i ,td ,th , label ,button, span, .form-control, .form-select"); // Can be extended, ex. $("div, p, span.someClass")

	//Storing the original size in a data attribute so size can be reset
	$affectedElements.each(function() {
		var $this = $(this);
		$this.data("orig-size", $this.css("font-size"));
	});
	var cnt = 0;
	var dcnt = 0
	$("#btn-increase").click(function() {
		if (cnt < 5) {
			changeFontSize(1);
			cnt += 1;
			dcnt -= 1;
		}
	})



	$("#btn-decrease").click(function() {
		if (dcnt < 5) {
			changeFontSize(-1);
			dcnt += 1;
			cnt -= 1;
		}
	})

	$("#btn-orig").click(function() {
		$affectedElements.each(function() {
			var $this = $(this);
			$this.css("font-size", $this.data("orig-size"));
		});
	})

	function changeFontSize(direction) {
		$affectedElements.each(function() {
			var $this = $(this);
			$this.css("font-size", parseInt($this.css("font-size")) + direction);
		});
	}
	
	
	
	$(".logo-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        dots: false,
        loop: true,
        margin: 15,
        nav : false,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsiveClass: true,
        responsive: {
            0:{
                items:1
            },
            768:{
                items:3
            },
            992:{
                items:4
            },
            1200:{
                items:7
            }
        }
    });

});


document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const toggle = document.querySelector('#toggle');

  
  const darkMode = sessionStorage.getItem('darkMode') === 'true';

  if (darkMode) {
    body.classList.add('dark');
    if (toggle) toggle.checked = true;
  }

  if (toggle) {
    toggle.addEventListener('change', () => {
     
      body.classList.toggle('dark');

      
      const isDark = body.classList.contains('dark');
      sessionStorage.setItem('darkMode', isDark);

    });
  }
});
